users = [
    {"name": "luis"},
    {"name": "carl"},
    {"name": "john"}
]